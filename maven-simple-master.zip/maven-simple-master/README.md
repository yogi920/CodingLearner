# example -> change

Example Maven project generated using `maven-archetype-quickstart`

-this change will trigger a build

new change




